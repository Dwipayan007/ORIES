﻿/// <reference path="../app.js" />
ores.controller("devLoginCntrl", ["$scope", function ($scope) {

}])