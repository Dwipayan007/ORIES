﻿/// <reference path="../app.js" />
ores.controller("devSignupCtrl", ["$scope", function ($scope) {

}]);