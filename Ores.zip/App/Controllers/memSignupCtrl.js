﻿/// <reference path="../app.js" />
ores.controller("memSignupCtrl", ["$scope", function ($scope) {

}]);