﻿/// <reference path="../app.js" />
ores.controller("memLoginCtrl", ["$scope", function ($scope) {

}])