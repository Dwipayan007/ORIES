﻿/// <reference path="../app.js" />
ores.controller("homeController", ["$scope", function ($scope) {

}]);