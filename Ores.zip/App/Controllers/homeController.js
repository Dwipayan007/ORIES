﻿/// <reference path="../app.js" />
ores.controller("homeController", ["$scope", function ($scope) {
    (function () {
        $("#slider-range").slider({
            range: true,
            min: 100000,
            max: 100000000,
            values: [5665399, 63689968],
            slide: function (event, ui) {
                $("#amount").val("₹" + ui.values[0] + " - ₹" + ui.values[1]);
            }
        });
        $("#amount").val("₹" + $("#slider-range").slider("values", 0) + " - ₹" + $("#slider-range").slider("values", 1));

    })();
    //$(window).load(function () {
        
    //});
}]);