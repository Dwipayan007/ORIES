﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ores.Models
{
    public class Developer
    {
        public string USERTYPE { get; set; }
        public string PNAME { get; set; }
        public string OWNERNAME { get; set; }
        public string WEBSITE { get; set; }
        public string ADDRESS { get; set; }
        public string PHNO { get; set; }
        public string EMAIL { get; set; }
        public string PASSWORD { get; set; }
        public string MEMBERID { get; set; }
        public string BUILDERNAME { get; set; }
    }
}