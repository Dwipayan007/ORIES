﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ores.Models
{
    public class Login
    {
        public string USERNAME { get; set; }
        public string PASSWORD { get; set; }
        public string USERTYPE { get; set; }
    }
}