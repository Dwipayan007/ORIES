﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ores.Models
{
    public class Member
    {
        public string userType { get; set; }
        public string password { get; set; }
        public string organisation { get; set; }
        public string category { get; set; }
        public string pan { get; set; }
        public string chairman { get; set; }
        public string address { get; set; }
        public string phno { get; set; }
        public string fax { get; set; }
        public string mobile { get; set; }
        public string email { get; set; }
        public string website { get; set; }
        public string representative { get; set; }
        public string designation { get; set; }
        public string rmobile { get; set; }
        public string remail { get; set; }

    }
}